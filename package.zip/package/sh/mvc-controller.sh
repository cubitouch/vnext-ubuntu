filename=$(zenity --title="New MVC Controller" --entry)
yo aspnet:MvcController "$filename"
