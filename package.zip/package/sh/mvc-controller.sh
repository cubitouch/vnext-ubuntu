filename=$(zenity --title="New MVC Controller" --entry)
yo aspnet:MvController "$filename"
