yo aspnet:PackageJson
