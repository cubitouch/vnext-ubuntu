filename=$(zenity --title="New JScript file" --entry)
yo aspnet:JScript "$filename"
