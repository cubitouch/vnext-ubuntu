filename=$(zenity --title="New HTML page" --entry)
yo aspnet:HTMLPage "$filename"
