filename=$(zenity --title="New Config" --entry)
yo aspnet:Config "$filename"
