yo aspnet:StartupClass
