filename=$(zenity --title="New Class" --entry)
yo aspnet:Class "$filename"
