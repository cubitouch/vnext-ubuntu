yo aspnet:BowerJson
