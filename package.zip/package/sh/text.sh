filename=$(zenity --title="New Text file" --entry)
yo aspnet:TextFile "$filename"
