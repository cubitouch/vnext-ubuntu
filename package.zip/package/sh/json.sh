filename=$(zenity --title="New JSON file" --entry)
yo aspnet:JSON "$filename"
