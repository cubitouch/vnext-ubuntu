filename=$(zenity --title="New CoffeeScript file" --entry)
yo aspnet:CoffeeScript "$filename"
