filename=$(zenity --title="New Gulp file" --entry)
yo aspnet:Gulpfile "$filename"
