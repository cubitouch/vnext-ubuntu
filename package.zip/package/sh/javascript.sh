filename=$(zenity --title="New JavaScript file" --entry)
yo aspnet:JavaScript "$filename"
