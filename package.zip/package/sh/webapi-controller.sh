filename=$(zenity --title="New WebApi Contoller" --entry)
yo aspnet:WebApiContoller "$filename"
