filename=$(zenity --title="New TypeScript" --entry)
yo aspnet:TypeScript "$filename"
