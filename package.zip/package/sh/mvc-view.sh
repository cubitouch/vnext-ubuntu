filename=$(zenity --title="Filename of your new MVC View" --entry) ; yo aspnet:MvcView "$filename"
