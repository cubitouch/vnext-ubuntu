filename=$(zenity --title="New MVC View" --entry)
yo aspnet:MvcView "$filename"
